'''
Created on 9 abr. 2019

@author: Maite Bernaus
@author: David Fernandez
'''
from COSBackend import CosBackend
    
def main(arg1):
  
    a = CosBackend(arg1.get('configCOS'))
    a.delete(arg1.get('bucket'), arg1.get('filename'))
    
